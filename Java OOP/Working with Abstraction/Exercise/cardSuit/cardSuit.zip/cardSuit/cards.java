package WorkingWithAbstraction.Exercise.cardSuit;

public enum cards {
        CLUBS,
        DIAMONDS,
        HEARTS,
        SPADES;
    }

